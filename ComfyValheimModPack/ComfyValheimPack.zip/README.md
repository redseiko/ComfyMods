# ComfyValheimPack

  * This modpack is used for the [Comfy Valheim](https://discord.gg/ameHJz5PFk) server to make installing mods faster.
    * It does not include all of our allowed mods, just a few that most players will find useful.
    * To see the full allowed mods list go to the `#allowed-mods` channel in our Discord.

  - A modpack is just a list of mods that informs the mod manager which other mods to install (dependencies).
    - However, a few mod configuration files have been added configured for our server (like QuickConnect).

  * For any questions or help, open a ticket in our Discord `#get-support` channel.

### Links

  * See source at: [GitHub](https://github.com/redseiko/ComfyMods/tree/main/ComfyValheimModPack).
